use std::fmt;
use anchor_lang::{
    prelude::*,
    solana_program::borsh::try_from_slice_unchecked,
};

declare_id!("DTXRUWcdYCAKbjvhpd9ztAUoMENrzztQkSoiJcFtR7dw");

#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub enum Operation {
    Create,
    Edit { size: u64 },
    Complete { offset: u64, data: Vec<u8> },
    Seal,
}

impl fmt::Display for Operation {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
       match *self {
        Operation::Create => write!(f, "<Create>"),
        Operation::Edit {size: _}=> write!(f, "<Edit>"),
        Operation::Complete {offset: _, data: _} => write!(f, "<Complete>"),
        Operation::Seal => write!(f, "<Seal>"),
       }
    }
}


#[derive(Clone, AnchorSerialize, AnchorDeserialize)]
pub struct Operations {
    pub lof_opers: Vec<Operation>,
}

const BEGIN_SIGNATURE : [u8; 32] = [45,45,45,45,45,66,69,71,73,78,32,126,50,48,50,51,126,32,84,79,68,79,32,76,73,83,84,45,45,45,45,45];
const END_SIGNATURE   : [u8; 32] = [45,45,45,45,45,69,78,68,32,126,50,48,50,51,126,32,84,79,68,79,32,76,73,83,84,45,45,45,45,45,0,0];

fn handle_operations(accounts: &[AccountInfo], operations_data: Operations, program_id: &Pubkey) -> Result<()> {

    let accounts_iter = &mut accounts.iter();  
    let operations: Operations = operations_data; 
    
    for operation in operations.lof_opers { 

        let list = next_account_info(accounts_iter)?; 
        if list.owner != program_id {
            return Err(anchor_lang::error::ErrorCode::AccountOwnedByWrongProgram.into())  
        }     

        msg!("[*] Operation {}", operation);   
        
        match operation { 
            
            Operation::Create => {
                
                let header = &mut list.data.borrow_mut()[0..32];
                if BEGIN_SIGNATURE == header {
                    return Err(anchor_lang::error::ErrorCode::Deprecated.into())  
                }

                header[0..32].copy_from_slice(&BEGIN_SIGNATURE);      
            }

            Operation::Edit { size} => {
                
                {
                    let header = &mut list.data.borrow_mut()[0..32];
                    if BEGIN_SIGNATURE != header {
                        return Err(anchor_lang::error::ErrorCode::Deprecated.into())
                    }
                }

                list.realloc(size as usize, false)?;    
            }

            Operation::Complete { offset, data } => {
                
                {
                    let header = &list.data.borrow_mut()[0..32];
                    if BEGIN_SIGNATURE != header {
                        return Err(anchor_lang::error::ErrorCode::Deprecated.into())
                    }
                }
                
                if offset < 0x20 {
                    return Err(anchor_lang::error::ErrorCode::ConstraintAssociated.into())
                }

                if offset as usize + data.len() > list.data_len() {
                    return Err(anchor_lang::error::ErrorCode::ConstraintAssociated.into())
                }

                list.data.borrow_mut()[offset as usize..offset as usize + data.len()].copy_from_slice(&data);
            }

            Operation::Seal => {

                let header = &mut list.data.borrow_mut()[0..32];

                if BEGIN_SIGNATURE != header {
                    return Err(anchor_lang::error::ErrorCode::Deprecated.into())   
                }
                
                header[0..32].copy_from_slice(&END_SIGNATURE);
            }

        }

    }

    Ok(())
}

#[program]
pub mod istm {
    use super::*;

    pub fn create_list(ctx: Context<CreateList>, operations: Vec<u8>) -> Result<()> {
        
        msg!("[*] Joining ISTM List");

        let program_id: &Pubkey = &ctx.program_id;
        let raw_operations: &[u8] = &operations;
        let operations_data: Operations = try_from_slice_unchecked(raw_operations)?; 
        
        if ctx.remaining_accounts.len() < operations_data.lof_opers.len() {  
            Err(anchor_lang::error::ErrorCode::ConstraintAssociated.into())
        }
        else {
            handle_operations(ctx.remaining_accounts, operations_data, program_id).ok();
            Ok(())
        }

    }
}


#[derive(Accounts)]
pub struct CreateList<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
}